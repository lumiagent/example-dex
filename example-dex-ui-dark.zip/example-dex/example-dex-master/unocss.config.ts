import { defineConfig, presetUno } from 'unocss';

export default defineConfig({
  // more presets: https://uno.antfu.me/?s=preset
  presets: [presetUno()]
});
