import { useEffect, useState } from 'react';

import {
  AdvancedChart,
  CreateOrder,
  LightweightChart,
  Orderbook,
  Spinner,
  SymbolHeader,
  SymbolSelection
} from '~/components';
import { OrderTabs } from '~/components/OrderTabs';

const useAdvancedCharts = import.meta.env.VITE_USE_ADVANCED_CHARTS === 'true';

export default function Index() {
  const [symbol, setSymbol] = useState<string>();

  useEffect(() => {
    if (symbol) return;
    setSymbol('PERP_BTC_USDC');
  }, [symbol, setSymbol]);

  if (!symbol) {
    return <Spinner />;
  }

  return (
    <div
      className="grid grid-cols-[16rem_1fr_22rem] grid-rows-[1fr_auto] gap-4 p-4"
      style={{ height: 'calc(100vh - 3.5rem)' }}
    >
      {/* Left sidebar: markets list and symbol selector */}
      <aside className="row-span-2 overflow-y-auto bg-[var(--color-secondary-bg)] p-4 rounded-md flex flex-col gap-4">
        {/* Symbol selection dropdown reused as a persistent component */}
        <SymbolSelection symbol={symbol} setSymbol={setSymbol} />
        {/* Placeholder for a markets list – you can enhance this by creating a
            dedicated MarketsList component that fetches available markets and
            displays price, volume and change similar to the reference UI. */}
        <div className="text-sm text-[var(--color-text-muted)] mt-4">
          {/* simple placeholder, feel free to replace with a list of markets */}
          <p>Markets list coming soon…</p>
        </div>
      </aside>

      {/* Centre content: chart and ticker information */}
      <main className="overflow-hidden flex flex-col gap-2">
        <SymbolHeader symbol={symbol} setSymbol={setSymbol} />
        <div className="flex-1 overflow-hidden">
          {useAdvancedCharts ? (
            <AdvancedChart symbol={symbol} />
          ) : (
            <LightweightChart symbol={symbol} />
          )}
        </div>
        {/* Placeholder for additional indicators below the chart */}
        {/* <div className="h-32 bg-[var(--color-secondary-bg)] mt-2 rounded-md"></div> */}
      </main>

      {/* Right sidebar: order book and order form */}
      <aside className="overflow-y-auto bg-[var(--color-secondary-bg)] p-4 rounded-md flex flex-col gap-4">
        <Orderbook symbol={symbol} />
        <CreateOrder symbol={symbol} />
      </aside>

      {/* Footer: positions and order history tabs */}
      <footer className="col-span-3 overflow-x-auto bg-[var(--color-secondary-bg)] p-2 rounded-md">
        <OrderTabs symbol={symbol} />
      </footer>
    </div>
  );
}
