import { Link } from '@remix-run/react';
import { FC } from 'react';

import { OrderlyConnect, WalletConnection } from '~/components';

/**
 * Primary navigation bar displayed at the top of the application.
 *
 * To mirror the reference trading terminal, we expose a horizontal list of
 * navigation links (some of which are placeholders) and display the wallet
 * connection controls on the right.  The layout is responsive and hides
 * non‑essential labels on narrow screens.  Colours are inherited from the
 * global CSS defined in global.css.
 */
export const NavBar: FC = () => {
  return (
    <nav
      className="w-full flex items-center justify-between px-4 py-2"
      style={{ backgroundColor: 'var(--color-secondary-bg)' }}
    >
      {/* Brand */}
      <div className="flex items-center gap-4">
        <h2 className="text-lg font-bold">
          <Link to="/" className="text-white">
            My DEX
          </Link>
        </h2>
        {/* Navigation links */}
        <ul className="hidden md:flex items-center gap-6 text-sm">
          <li>
            <Link to="/" className="hover:text-[var(--color-accent)]">
              Trading
            </Link>
          </li>
          <li>
            <Link to="#" className="hover:text-[var(--color-accent)]">
              Portfolio
            </Link>
          </li>
          <li>
            <Link to="#" className="hover:text-[var(--color-accent)]">
              Markets
            </Link>
          </li>
          <li>
            <Link to="#" className="hover:text-[var(--color-accent)]">
              Points
            </Link>
          </li>
          <li>
            <Link to="#" className="hover:text-[var(--color-accent)]">
              Leaderboard
            </Link>
          </li>
          <li>
            <Link to="#" className="hover:text-[var(--color-accent)]">
              Affiliate
            </Link>
          </li>
        </ul>
      </div>
      {/* Right side: total value (placeholder), wallet connection and network */}
      <div className="flex items-center gap-4">
        {/* Total value placeholder */}
        <div className="hidden sm:flex flex-col text-right text-xs">
          <span className="text-[var(--color-text-muted)]">Total value</span>
          <span>– USDC</span>
        </div>
        {/* Wallet connect button */}
        <WalletConnection />
        {/* Network / Connect overlay trigger */}
        <OrderlyConnect />
      </div>
    </nav>
  );
};
